package com.example.autoclicker

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        fun field(hint: String, value: Long) = EditText(this).apply {
            this.hint = hint
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(value.toString())
        }

        val xField = field("X position (pixels)", prefs.getInt("x", 500).toLong())
        val yField = field("Y position (pixels)", prefs.getInt("y", 1000).toLong())
        val intervalField = field("Interval (milliseconds)", prefs.getLong("interval", 500L))

        val saveButton = Button(this).apply {
            text = "Save"
            setOnClickListener {
                prefs.edit()
                    .putInt("x", xField.text.toString().toIntOrNull() ?: 500)
                    .putInt("y", yField.text.toString().toIntOrNull() ?: 1000)
                    .putLong("interval", (intervalField.text.toString().toLongOrNull() ?: 500L).coerceAtLeast(50L))
                    .apply()
                Toast.makeText(context, "Saved", Toast.LENGTH_SHORT).show()
            }
        }

        val settingsButton = Button(this).apply {
            text = "Open Accessibility Settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }

        val help = TextView(this).apply {
            text = "1. Turn on 'Auto Clicker' in Accessibility.\n" +
                "2. Set the X, Y and interval. Tap Save.\n" +
                "3. Open the target app. Tap START on the floating button."
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
            addView(help)
            addView(xField)
            addView(yField)
            addView(intervalField)
            addView(saveButton)
            addView(settingsButton)
        })
    }
}
