package com.example.autoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button

class AutoClickService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var toggleButton: Button? = null
    private lateinit var windowManager: WindowManager

    private val clickLoop = object : Runnable {
        override fun run() {
            if (!running) return
            val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
            val x = prefs.getInt("x", 500).toFloat()
            val y = prefs.getInt("y", 1000).toFloat()
            val interval = prefs.getLong("interval", 500L)

            val path = Path().apply { moveTo(x, y) }
            val stroke = GestureDescription.StrokeDescription(path, 0, 50)
            dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)

            handler.postDelayed(this, interval)
        }
    }

    override fun onServiceConnected() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val button = Button(this).apply {
            text = "START"
            setOnClickListener { toggle() }
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END }
        windowManager.addView(button, params)
        toggleButton = button
    }

    private fun toggle() {
        running = !running
        toggleButton?.text = if (running) "STOP" else "START"
        if (running) handler.post(clickLoop) else handler.removeCallbacks(clickLoop)
    }

    private fun stopAll() {
        running = false
        handler.removeCallbacks(clickLoop)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() = stopAll()

    override fun onDestroy() {
        stopAll()
        toggleButton?.let { windowManager.removeView(it) }
        toggleButton = null
        super.onDestroy()
    }
}
